# Ranked Band Beta

A single-file interactive frontend prototype for the Ranked Band school band platform.

## Launch on GitHub Pages (no downloads needed)

1. Create a **public** GitHub repository named `ranked-band`.
2. In that repository, choose **Add file → Create new file**.
3. Name the file `index.html`.
4. Copy the complete contents of `index.html` in this package and paste it into GitHub's browser editor.
5. Click **Commit changes**.
6. Open **Settings → Pages**.
7. Choose **Deploy from a branch**, select branch **main**, folder **/(root)**, and click **Save**.
8. Wait for GitHub to provide the Pages address.

## Important beta safety limits

This version uses browser `localStorage`, not secure accounts or a shared database. It is a demo/prototype only:

- Do not enter real student names, school emails, grades, recordings, or private data.
- Do not rely on its role switcher for permissions.
- Do not use it for official rankings or real qualification decisions.
- The reset countdown is browser-based, not server-authoritative.

## Production upgrade needed later

A real school deployment requires Firebase/another backend, secure authentication, server-side role checks, a database, scheduled protected reset functions, storage rules, audit logs, and a genuine performance scoring workflow.
